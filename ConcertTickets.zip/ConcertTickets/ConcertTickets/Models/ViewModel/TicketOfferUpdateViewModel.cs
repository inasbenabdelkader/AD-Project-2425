﻿namespace ConcertTickets.Models.ViewModel
{
	public class TicketOfferUpdateViewModel
	{
		public int Id { get; set; }
		public int NumTicketsOrdered { get; set; }
	}
}
