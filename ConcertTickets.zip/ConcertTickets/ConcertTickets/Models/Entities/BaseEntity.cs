﻿namespace ConcertTickets.Models.Entities
{
	public abstract class BaseEntity
	{
		public int Id { get; set; }
	}
}
